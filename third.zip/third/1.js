function check() {
    var user_name=form1.user.value;
    var user_pwd=form1.pwd.value;
    if((user_name=="")||(user_name==null)){
        alert("请输入用户名！");
        form1.user.focus();
        return;
    }
    else if((user_pwd=="")||(user_pwd==null)){
        alert("请输入密码！");
        form1.pwd.focus();
        return;}
    else if((user_name=="csy123")&(user_pwd==123456789)){
       document.getElementById('first').style.display='none';
       document.getElementById('second').style.display='block'
    }
    else {
        alert("密码或用户名错误，请检查！");
    }
}
function del1(){
        document.getElementById('project1').style.visibility = "hidden";
        document.getElementById('bt1').style.visibility = "hidden";
}
function del2(){
        document.getElementById('project2').style.visibility = "hidden";
        document.getElementById('bt2').style.visibility = "hidden";
}
function del3(){
        document.getElementById('project3').style.visibility = "hidden";
        document.getElementById('bt3').style.visibility = "hidden";
}
function del4(){
        document.getElementById('project4').style.visibility = "hidden";
        document.getElementById('bt4').style.visibility = "hidden";
}
function del5(){
        document.getElementById('project5').style.visibility = "hidden";
        document.getElementById('bt5').style.visibility = "hidden";
}
function del6(){
        document.getElementById('project6').style.visibility = "hidden";
        document.getElementById('bt6').style.visibility = "hidden";
}
